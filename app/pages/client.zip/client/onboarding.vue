<template>
  <div
    class="bg-card min-h-screen flex items-center justify-center p-4 text-foreground"
  >
    <div class="w-full max-w-md space-y-8">
      <!-- Form Card -->
      <div
        class="bg-background border border-border rounded-2xl p-6 shadow-app space-y-5"
      >
        <h1 class="text-2xl mb-2 font-bold text-foreground">
          Lengkapi Profil Bisnis
        </h1>
        <p class="text-sm text-secondary">
          Mari kenali bisnis Anda agar kami bisa memberikan layanan terbaik.
        </p>
        <div class="space-y-1.5">
          <Input
            type="text"
            label="Nama Bisnis"
            placeholder="Contoh: Kedai Kopi Senja"
            max-width="100vw"
          />
        </div>

        <div class="space-y-1.5">
          <Select
            v-model="team"
            label="Tipe Bisnis"
            :options="businessTypes"
            placeholder="Pilih tipe bisnis"
            searchable
            max-width="100vw"
          />
        </div>
        <div class="space-y-1.5">
          <Input
            type="number"
            label="Nomor Whatsapp"
            placeholder="Contoh: 08262626262"
            max-width="100vw"
          />
        </div>
        <div class="space-y-1.5">
          <Input
            type="textarea"
            label="Alamat"
            placeholder="Contoh: Jl. kenangan ....."
            max-width="100vw"
          />
        </div>

        <Button
          variant="solid"
          class="w-full"
          :disabled="!isValid"
          @click="submit"
        >
          Simpan & Lanjutkan
        </Button>
      </div>
    </div>
  </div>
</template>

<script setup>
definePageMeta({
  layout: "auth", // atau layout khusus tanpa sidebar
  title: "Onboarding",
});
import { ref, computed } from "vue";

const form = ref({
  businessName: "",
  businessType: "",
  phone: "",
});

const businessTypes = [
  {
    label: "Kuliner / F&B",
    value: "kuliner-fnb",
  },
  {
    label: "Retail / Toko Online",
    value: "retail-toko-online",
  },
  {
    label: "Jasa / Konsultan",
    value: "jasa-konsultan",
  },
  {
    label: "Kesehatan / Klinik",
    value: "kesehatan-klinik",
  },
  {
    label: "Pendidikan",
    value: "pendidikan",
  },
  {
    label: "Lainnya",
    value: "lainnya",
  },
];

const isValid = computed(() => form.value.businessName.trim().length > 0);

const submit = () => {
  // TODO: call API
  navigateTo("/client/selamat-datang");
};
</script>
