<template>
  <div
    class="bg-background min-h-screen flex items-center justify-center p-4 text-foreground"
  ></div>
</template>

<script setup>
definePageMeta({
  layout: "auth", // tanpa sidebar
  title: "Selamat Datang",
});

import {
  PartyPopper,
  Globe,
  TrendingUp,
  Headphones,
  ArrowRight,
} from "lucide-vue-next";
</script>
